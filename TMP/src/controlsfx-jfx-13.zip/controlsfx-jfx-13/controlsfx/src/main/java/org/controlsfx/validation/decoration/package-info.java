/**
 * A package containing decoration API specific to the validation framework.
 */
package org.controlsfx.validation.decoration;