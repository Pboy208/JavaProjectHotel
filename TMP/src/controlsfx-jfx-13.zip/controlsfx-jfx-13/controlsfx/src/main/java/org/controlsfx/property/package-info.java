/**
 * A package containing a number of useful classes related to the 
 * {@link org.controlsfx.control.PropertySheet} control.
 */
package org.controlsfx.property;